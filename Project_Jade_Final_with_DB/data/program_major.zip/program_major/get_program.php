<?php
require_once("dbcontroller.php");
$db_handle = new DBController();


if(!empty($_POST["program_id"])) {
	$query ="SELECT * FROM ems_program_setup WHERE program_type_id = '" . $_POST["program_id"] . "'";
	$results = $db_handle->runQuery($query);
?>
	<option value="">Select Programv Type</option>
<?php
	foreach($results as $program) {
?>
	<option value="<?php echo $program["id"]; ?>"><?php echo $program["program_name"]; ?></option>
<?php
	}
}
?>
