<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
$query ="SELECT * FROM ems_program_type";
$results = $db_handle->runQuery($query);
?>
<html>
<head>
<TITLE>jQuery Dependent DropDown List - Program and Major</TITLE>
<head>
<style>
body{width:610px;}
.frmDronpDown {border: 1px solid #F0F0F0;background-color:#C8EEFD;margin: 2px 0px;padding:40px;}
.demoInputBox {padding: 10px;border: #F0F0F0 1px solid;border-radius: 4px;background-color: #FFF;width: 50%;}
.row{padding-bottom:15px;}
</style>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
function getProgram(val) {
	$.ajax({
	type: "POST",
	url: "get_program.php",
	data:'program_id='+val,
	success: function(data){
		$("#program-list").html(data);
	}
	});
}function getMajor(val) {
	$.ajax({
	type: "POST",
	url: "get_major.php",
	data:'program_id='+val,
	success: function(data){
		$("#major-list").html(data);
	}
	});
}

function selectProgram(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>
</head>
<body>
<div class="frmDronpDown">
<div class="row">
<label>Program:</label><br/>

<select name="programType" id="program_type-list" class="demoInputBox" onChange="getProgram(this.value);">
<option value="">Select Type</option>
<?php
foreach($results as $program) {
?>
<option value="<?php echo $program["cat_id"]; ?>"><?php echo $program["category"]; ?></option>
<?php
}
?>
</select>



<select name="" id="program-list" class="demoInputBox" onChange="getMajor(this.value);">
<option value="">Select Program</option>
<?php
foreach($results as $program) {
?>
<option value="<?php echo $program["id"]; ?>"><?php echo $program["program_name"]; ?></option>
<?php
}
?>
</select>
</div>
<div class="row">
<label>Major:</label><br/>
<select name="major" id="major-list" class="demoInputBox">
<option value="">Select Major</option>
</select>
</div>
</div>
</body>
</html>
