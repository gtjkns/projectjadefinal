<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["program_id"])) {
	$query ="SELECT * FROM ems_major_setup WHERE program_id = '" . $_POST["program_id"] . "'";
	$results = $db_handle->runQuery($query);
?>
	<option value="">Select Major</option>
<?php
	foreach($results as $major) {
?>
	<option value="<?php echo $major["id"]; ?>"><?php echo $major["name"]; ?></option>
<?php
	}
}
?>
